# Clear the workspace
rm(list = ls())
setwd("C:/Users/aanchalxchadda/Downloads/")
data <- read.csv('data.csv')

# Load necessary libraries
library(caret)
library(rpart)
library(rpart.plot)
library(leaps)
library(glmnet)
library(class)
library(randomForest)
library(data.table)

# Remove rows with missing values
data[data == ""] <- NA
data <- data[complete.cases(data), -c(0,20)]
head(data)

# converting categorical features into dummy variables
# for type_of_meal_plan, room_type_reserved, market_segment_type
# AND booking_status


# Load required libraries if not already loaded
library(tidyr)
library(dplyr)
library(fastDummies)

data <- dummy_cols(data, select_columns = c("type_of_meal_plan", "room_type_reserved","market_segment_type","booking_status"))

# remove all spaces from the column names
colnames(data) <- gsub(" ", "", colnames(data))

#remove unnecessary columns

columns_to_remove <- c("Booking_ID", "type_of_meal_plan", "room_type_reserved", "market_segment_type", "booking_status", "booking_status_Not_Canceled")

data <- data[, !(names(data) %in% columns_to_remove)]

# Splitting data into training (80%) and testing (20%) sets
set.seed(123)  # For reproducibility
index <- createDataPartition(data$booking_status_Canceled, p = 0.8, list = FALSE)


# Creating training and testing datasets
training_data <- data[index, ]
testing_data <- data[-index, ]

#Create regression models to get RSQ and accuracy and MSE
#logistic regression, linear, lasso and ridge, and random forest
#summary on test dataset but regressions on train

View(training_data)

# Logistic Model----------
# Create a logistic regression model using the training dataset

# Prediction Model ----------
# Logistic model-----
logistic_model <- glm(booking_status_Canceled ~ .,  data = training_data, family = 'binomial')
summary(logistic_model)

# Get predicted probabilities for the training dataset
predicted_probabilities <- predict(logistic_model, type = "response")

# Obtain predicted classes (0 or 1) based on a threshold (e.g., 0.5)
predicted_classes <- ifelse(predicted_probabilities > 0.5, 1, 0)

# Calculate accuracy
accuracy <- mean(predicted_classes == testing_data$booking_status_Canceled)
print(paste("Accuracy:", accuracy))

summary(logistic_model)

# Random Forest
# Load additional Libraries to start Random Forest ----------
library("randomForestExplainer")

# Build an unpruned classification tree first
tree_model <- rpart(booking_status_Canceled ~ ., data=training_data, method="class")


# Build the classification tree with pruning
library(rpart)

# Assuming 'training_data' and 'testing_data' contain predictors and 'booking_status_Canceled' is the target variable
# Build an unpruned classification tree
tree_model <- rpart(booking_status_Canceled ~ ., data = training_data, method = "class")

# Prune the tree
optimal_cp <- tree_model$cptable[which.min(tree_model$cptable[,"xerror"]), "CP"]
pruned_tree <- prune(tree_model, cp = optimal_cp)

#  UNCOMMENT THIS IF YOU'RE ON WINDOWS, U NEED TO CALL THIS FUNCTION
windows()   
rpart.plot(pruned_tree, main="Pruned Classification Tree for Booking Status")

# Predict using the pruned tree on test data
pruned_pred <- predict(pruned_tree, testing_data)

# Convert predicted values to factor with the same levels as 'booking_status_Canceled' in test data
pruned_pred_factor <- factor(pruned_pred, levels = levels(as.factor(training_data$booking_status_Canceled)))

# Building Random Forest Models ----------
# Build different random forest models with varying parameters
training_data$booking_status_Canceled <- as.factor(training_data$booking_status_Canceled)
# Forest1: Default parameters
forest1 <- randomForest(booking_status_Canceled ~ ., data=training_data, method="class", localImp = TRUE)

# Evaluating Model Accuracy
booking_status_Canceled = predict(forest1, testing_data)
accuracy <- mean(booking_status_Canceled == testing_data$booking_status_Canceled)
print(paste("Accuracy f1:", accuracy))

# Forest2: Increased number of trees
forest2 <- randomForest(booking_status_Canceled ~ ., data=training_data, ntree=500, method="class", localImp = TRUE)

# Evaluating Model Accuracy
booking_status_Canceled = predict(forest2, testing_data)
accuracy <- mean(booking_status_Canceled == testing_data$booking_status_Canceled)
print(paste("Accuracy f2:", accuracy))

# Forest3: More variables tried at each split
forest3 <- randomForest(booking_status_Canceled ~ ., data=training_data, mtry=3, method="class", localImp = TRUE)

# Evaluating Model Accuracy
booking_status_Canceled = predict(forest3, testing_data)
accuracy <- mean(booking_status_Canceled == testing_data$booking_status_Canceled)
print(paste("Accuracy f3:", accuracy))

explain_forest(forest1, path = "f1.html", data=training_data, no_of_pred_plots = 3,pred_grid = 100)
explain_forest(forest2, path = "f2.html", data=training_data, no_of_pred_plots = 3,pred_grid = 100)
explain_forest(forest3, path = "f3.html", data=training_data, no_of_pred_plots = 3,pred_grid = 100)